BUCKET_NAME = "bucket-pfb_keepcoding2"
DB_BLOB_PATH = "Result_database/results.db"